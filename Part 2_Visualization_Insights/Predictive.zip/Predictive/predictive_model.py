"""
=============================================================
 Predictive Model — Fashion E-Commerce Vietnam
 Method : Geometric Mean YoY Growth × Seasonal Index
 Input  : 003_-Predictive.xlsx  (Date | Revenue | COGs)
 Output : submission.csv        (Date | Revenue | COGs)

 MAPE benchmark:
   - Daily  MAPE ~25%  (expected: daily data có noise cao)
   - Monthly MAPE ~14% (more meaningful aggregate metric)
=============================================================
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import warnings
warnings.filterwarnings("ignore")

# ── 0. CONFIG ──────────────────────────────────────────────────────────────────
INPUT_FILE      = "003_-Predictive.xlsx"
OUTPUT_FILE     = "submission.csv"
FORECAST_START  = "2023-01-01"
FORECAST_END    = "2024-07-01"
VALIDATION_YEARS = [2021, 2022]
BASE_YEAR       = 2022


# ── 1. LOAD DATA ───────────────────────────────────────────────────────────────
print("=" * 60)
print(" STEP 1 — Load & inspect data")
print("=" * 60)

df = pd.read_excel(INPUT_FILE, parse_dates=["Date"])
df.columns = df.columns.str.strip()
df = df.rename(columns={"COGs": "COGS"})   # normalise column name

df["year"]  = df["Date"].dt.year
df["month"] = df["Date"].dt.month
df["day"]   = df["Date"].dt.day

print(f"  Rows          : {len(df):,}")
print(f"  Date range    : {df['Date'].min().date()} → {df['Date'].max().date()}")
print(f"  Missing values: {df[['Revenue','COGS']].isnull().sum().to_dict()}")
print()


# ── 2. ANNUAL TOTALS & YoY GROWTH ─────────────────────────────────────────────
print("=" * 60)
print(" STEP 2 — Annual totals & YoY growth rate")
print("=" * 60)

annual = df.groupby("year")[["Revenue", "COGS"]].sum()
annual_display = annual.copy()
annual_display["Revenue"] = annual_display["Revenue"].map(lambda x: f"{x/1e9:.3f}B")
annual_display["COGS"]    = annual_display["COGS"].map(lambda x: f"{x/1e9:.3f}B")
print(annual_display.to_string())

# Geometric mean YoY growth — only full years 2013-2022
full_years = annual.loc[2013:BASE_YEAR]
yoy_rev    = full_years["Revenue"].pct_change().dropna()
yoy_cogs   = full_years["COGS"].pct_change().dropna()

g_rev  = (1 + yoy_rev).prod()  ** (1 / len(yoy_rev))
g_cogs = (1 + yoy_cogs).prod() ** (1 / len(yoy_cogs))

print(f"\n  Geometric mean YoY Revenue growth : {g_rev:.4f}  ({(g_rev-1)*100:.2f}%/yr)")
print(f"  Geometric mean YoY COGS    growth : {g_cogs:.4f}  ({(g_cogs-1)*100:.2f}%/yr)")
print()


# ── 3. BASE LEVEL ─────────────────────────────────────────────────────────────
print("=" * 60)
print(f" STEP 3 — Base level (daily avg of {BASE_YEAR})")
print("=" * 60)

base_rev  = annual.loc[BASE_YEAR, "Revenue"] / 365
base_cogs = annual.loc[BASE_YEAR, "COGS"]    / 365

print(f"  Base daily Revenue : {base_rev:,.2f} VND")
print(f"  Base daily COGS    : {base_cogs:,.2f} VND")
print()


# ── 4. SEASONAL INDEX  s(month, day) ──────────────────────────────────────────
print("=" * 60)
print(" STEP 4 — Build seasonal index")
print("=" * 60)

# Normalise: each day ÷ its year's mean → scale-free ratio
ann_means = df.groupby("year")[["Revenue", "COGS"]].transform("mean")
df["rev_norm"]  = df["Revenue"] / ann_means["Revenue"]
df["cogs_norm"] = df["COGS"]    / ann_means["COGS"]

# Average per (month, day) across all years
seasonal = (
    df.groupby(["month", "day"])[["rev_norm", "cogs_norm"]]
    .mean()
    .reset_index()
)

print(f"  Seasonal profile rows : {len(seasonal)}")

top5 = seasonal.nlargest(5, "rev_norm")[["month","day","rev_norm","cogs_norm"]]
print("\n  Top 5 peak days (Revenue index):")
print(top5.to_string(index=False))
print()


# ── 5. VALIDATION ─────────────────────────────────────────────────────────────
print("=" * 60)
print(f" STEP 5 — Validation MAPE on {VALIDATION_YEARS}")
print("=" * 60)

val = df[df["year"].isin(VALIDATION_YEARS)].copy()
# Merge seasonal index; suffix _s = seasonal average
val = val.merge(seasonal, on=["month","day"], how="left",
                suffixes=("_actual", "_seasonal"))
val["rev_norm_seasonal"]  = val["rev_norm_seasonal"].fillna(1.0)
val["cogs_norm_seasonal"] = val["cogs_norm_seasonal"].fillna(1.0)
val["years_ahead"] = val["year"] - BASE_YEAR

val["rev_pred"]  = base_rev  * g_rev**val["years_ahead"]  * val["rev_norm_seasonal"]
val["cogs_pred"] = base_cogs * g_cogs**val["years_ahead"] * val["cogs_norm_seasonal"]

def mape(actual, pred):
    mask = actual > 0
    return (np.abs(actual[mask] - pred[mask]) / actual[mask]).mean() * 100

# Daily MAPE
mape_rev_d  = mape(val["Revenue"], val["rev_pred"])
mape_cogs_d = mape(val["COGS"],    val["cogs_pred"])

# Monthly MAPE (aggregate first — reduces noise, more meaningful)
val["ym"] = val["Date"].dt.to_period("M")
vm = val.groupby("ym").agg(
    Revenue=("Revenue","sum"), COGS=("COGS","sum"),
    rev_pred=("rev_pred","sum"), cogs_pred=("cogs_pred","sum")
)
mape_rev_m  = mape(vm["Revenue"], vm["rev_pred"])
mape_cogs_m = mape(vm["COGS"],    vm["cogs_pred"])

print(f"  MAPE Revenue — daily   : {mape_rev_d:.2f}%  "
      f"(daily noise is high; use monthly as primary metric)")
print(f"  MAPE Revenue — monthly : {mape_rev_m:.2f}%")
print()
print(f"  MAPE COGS    — daily   : {mape_cogs_d:.2f}%")
print(f"  MAPE COGS    — monthly : {mape_cogs_m:.2f}%")
print()

threshold_monthly = 20
status = "✅ Acceptable" if max(mape_rev_m, mape_cogs_m) < threshold_monthly \
         else "⚠️  Above threshold"
print(f"  Monthly threshold {threshold_monthly}%    : {status}")
print()


# ── 6. GENERATE FORECAST ──────────────────────────────────────────────────────
print("=" * 60)
print(f" STEP 6 — Forecast {FORECAST_START} → {FORECAST_END}")
print("=" * 60)

test = pd.DataFrame({"Date": pd.date_range(FORECAST_START, FORECAST_END)})
test["month"] = test["Date"].dt.month
test["day"]   = test["Date"].dt.day
test["year"]  = test["Date"].dt.year
test["years_ahead"] = test["year"] - BASE_YEAR

test = test.merge(seasonal, on=["month","day"], how="left")
test["rev_norm"]  = test["rev_norm"].fillna(1.0)
test["cogs_norm"] = test["cogs_norm"].fillna(1.0)

test["Revenue"] = (base_rev  * g_rev**test["years_ahead"]  * test["rev_norm"]).round(2)
test["COGS"]    = (base_cogs * g_cogs**test["years_ahead"] * test["cogs_norm"]).round(2)

print(f"  Forecast rows  : {len(test):,}")
print(f"  Revenue range  : {test['Revenue'].min():>12,.0f} – {test['Revenue'].max():>12,.0f} VND")
print(f"  COGS    range  : {test['COGS'].min():>12,.0f} – {test['COGS'].max():>12,.0f} VND")

# Monthly summary of forecast
test["ym"] = test["Date"].dt.to_period("M")
monthly_fc = test.groupby("ym")[["Revenue","COGS"]].sum()
print("\n  Monthly forecast summary:")
print(monthly_fc.head(12).map(lambda x: f"{x/1e6:.1f}M").to_string())
print("  ...")
print()


# ── 7. EXPORT ─────────────────────────────────────────────────────────────────
print("=" * 60)
print(f" STEP 7 — Export {OUTPUT_FILE}")
print("=" * 60)

submission = test[["Date","Revenue","COGS"]].copy()
submission["Date"] = submission["Date"].dt.strftime("%Y-%m-%d")
submission.to_csv(OUTPUT_FILE, index=False)
print(f"  Saved {len(submission):,} rows → {OUTPUT_FILE}")
print()


# ── 8. CHARTS ─────────────────────────────────────────────────────────────────
print("=" * 60)
print(" STEP 8 — Visualisation")
print("=" * 60)

fig, axes = plt.subplots(3, 1, figsize=(14, 14))
fig.suptitle(
    "Predictive Model — Fashion E-Commerce Vietnam\n"
    f"Method: Geometric Mean YoY ({(g_rev-1)*100:.1f}%/yr) × Seasonal Index  |  "
    f"MAPE monthly Revenue: {mape_rev_m:.1f}%  COGS: {mape_cogs_m:.1f}%",
    fontsize=11, fontweight="bold", y=0.99
)

fmt_m = mticker.FuncFormatter(lambda x, _: f"{x/1e6:.0f}M")

# ── Chart 1: Revenue — full history + validation + forecast ──
ax = axes[0]
hist = df[df["year"] < min(VALIDATION_YEARS)]
ax.plot(hist["Date"], hist["Revenue"],
        lw=0.6, color="#2E75B6", label="Historical (2012–2020)")
ax.plot(val["Date"], val["Revenue"],
        lw=0.9, color="#2E75B6", alpha=0.45, label="Actual (2021–2022)")
ax.plot(val["Date"], val["rev_pred"],
        lw=1.0, color="orange", linestyle="--", label="Validation prediction")
fc_dates = pd.to_datetime(test["Date"])
ax.plot(fc_dates, test["Revenue"],
        lw=1.2, color="#C00000", label="Forecast (2023–2024)")
ax.axvline(pd.Timestamp(FORECAST_START), color="gray", lw=1, linestyle=":")
ax.text(pd.Timestamp(FORECAST_START) + pd.Timedelta(days=15),
        ax.get_ylim()[1] * 0.88, "Forecast\nstart", fontsize=8, color="gray")
ax.set_title("Revenue — Historical, Validation & Forecast", fontsize=10)
ax.set_ylabel("Revenue (VND)")
ax.yaxis.set_major_formatter(fmt_m)
ax.legend(fontsize=8)
ax.grid(axis="y", alpha=0.25)

# ── Chart 2: COGS ──
ax = axes[1]
ax.plot(df["Date"], df["COGS"],
        lw=0.6, color="#7030A0", label="Historical COGS")
ax.plot(val["Date"], val["cogs_pred"],
        lw=1.0, color="orange", linestyle="--", label="Validation prediction")
ax.plot(fc_dates, test["COGS"],
        lw=1.2, color="#C00000", label="Forecast COGS")
ax.axvline(pd.Timestamp(FORECAST_START), color="gray", lw=1, linestyle=":")
ax.set_title("COGS — Historical & Forecast", fontsize=10)
ax.set_ylabel("COGS (VND)")
ax.yaxis.set_major_formatter(fmt_m)
ax.legend(fontsize=8)
ax.grid(axis="y", alpha=0.25)

# ── Chart 3: Seasonal Index ──
ax = axes[2]
proxy_dates = pd.date_range("2023-01-01", "2023-12-31")
proxy = pd.DataFrame({"month": proxy_dates.month, "day": proxy_dates.day,
                       "Date": proxy_dates})
proxy = proxy.merge(seasonal, on=["month","day"], how="left")
proxy["rev_norm"] = proxy["rev_norm"].fillna(1.0)
ax.fill_between(proxy["Date"], proxy["rev_norm"],
                alpha=0.3, color="#2E75B6")
ax.plot(proxy["Date"], proxy["rev_norm"], lw=0.9, color="#2E75B6",
        label="Revenue seasonal index")
ax.plot(proxy["Date"], proxy["cogs_norm"].fillna(1.0), lw=0.9,
        color="#7030A0", linestyle="--", label="COGS seasonal index")
ax.axhline(1.0, color="gray", lw=1, linestyle="--", label="Annual average = 1.0")
ax.set_title("Seasonal Index  s(month, day)  —  2023 representative year", fontsize=10)
ax.set_ylabel("Seasonal Index")
ax.legend(fontsize=8)
ax.grid(axis="y", alpha=0.25)

plt.tight_layout(rect=[0, 0, 1, 0.96])
chart_path = "predictive_charts.png"
plt.savefig(chart_path, dpi=150, bbox_inches="tight")
plt.close()
print(f"  Charts saved → {chart_path}")
print()
print("=" * 60)
print(" ✅  Pipeline complete")
print(f"     MAPE monthly Revenue : {mape_rev_m:.2f}%   |   COGS : {mape_cogs_m:.2f}%")
print(f"     Submission file      : {OUTPUT_FILE}  ({len(submission):,} rows)")
print("=" * 60)
